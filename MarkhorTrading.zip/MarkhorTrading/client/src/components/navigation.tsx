import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Mountain } from "lucide-react";

export default function Navigation() {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 80);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };

  return (
    <nav className={`fixed top-0 w-full z-50 transition-all duration-300 ${
      isScrolled ? "glass-morph backdrop-blur-xl" : ""
    }`}>
      <div className="container mx-auto px-6 py-4">
        <div className="flex justify-between items-center">
          <div className="flex items-center space-x-4">
            <div className="relative">
              <div className="w-12 h-12 gold-gradient rounded-xl flex items-center justify-center animate-pulse-glow shadow-lg">
                <Mountain className="text-navy font-bold" size={24} />
              </div>
              <div className="absolute -top-1 -right-1 w-4 h-4 bg-emerald-500 rounded-full animate-ping"></div>
            </div>
            <div className="flex flex-col">
              <span className="text-3xl font-black bg-gradient-to-r from-primary via-yellow-300 to-primary bg-clip-text text-transparent brand-3d premium-text-glow tracking-wide">
                MARKHOR
              </span>
              <span className="text-sm font-bold text-accent tracking-[0.2em] -mt-1 premium-text-glow">
                TRADER
              </span>
            </div>
          </div>
          
          <div className="hidden md:flex space-x-8">
            <button 
              onClick={() => scrollToSection("home")}
              className="hover:text-primary transition-colors duration-300"
            >
              Home
            </button>
            <button 
              onClick={() => scrollToSection("trading")}
              className="hover:text-primary transition-colors duration-300"
            >
              Trading
            </button>
            <button 
              onClick={() => scrollToSection("analytics")}
              className="hover:text-primary transition-colors duration-300"
            >
              Analytics
            </button>
            <button 
              onClick={() => scrollToSection("services")}
              className="hover:text-primary transition-colors duration-300"
            >
              Services
            </button>
            <button 
              onClick={() => scrollToSection("contact")}
              className="hover:text-primary transition-colors duration-300"
            >
              Contact
            </button>
          </div>
          
          <div className="flex space-x-4">
            <Button variant="outline" className="border-primary text-primary hover:bg-primary hover:text-primary-foreground">
              Login
            </Button>
            <Button className="gold-gradient text-primary-foreground font-semibold hover:scale-105 transition-transform duration-300 animate-glow">
              Start Trading
            </Button>
          </div>
        </div>
      </div>
    </nav>
  );
}

import { Card, CardContent } from "@/components/ui/card";
import { TrendingUp, Box, Shield } from "lucide-react";
import EnhancedScrollAnimated, { ParallaxScroll, MouseTracking } from "./enhanced-scroll-animations";
import AdvancedTradingScene from "./advanced-trading-scene";

export default function TradingPlatform() {
  return (
    <section id="trading" className="py-32 bg-gradient-to-b from-background to-slate-900 relative">
      <div className="container mx-auto px-6">
        <div className="text-center mb-20">
          <EnhancedScrollAnimated direction="rotate" duration={1.2}>
            <h2 className="text-5xl md:text-6xl font-black mb-6 bg-gradient-to-r from-white to-primary bg-clip-text text-transparent">
              Advanced Trading Suite
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Harness the power of cutting-edge technology with our premium trading platform
            </p>
          </EnhancedScrollAnimated>
        </div>
        
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Advanced Trading Visualization */}
          <EnhancedScrollAnimated direction="left" delay={200}>
            <MouseTracking intensity={0.1}>
              <AdvancedTradingScene />
            </MouseTracking>
          </EnhancedScrollAnimated>
          
          <EnhancedScrollAnimated direction="right" delay={400}>
            <div className="space-y-8">
              <Card className="trading-card ultra-glass border-primary/30 hover:border-primary/60 transition-all duration-500 hover:scale-105 animate-scale-in">
                <CardContent className="p-8">
                  <div className="flex items-center mb-4">
                    <div className="w-12 h-12 gold-gradient rounded-lg flex items-center justify-center mr-4 animate-pulse-glow">
                      <TrendingUp className="text-primary-foreground" size={24} />
                    </div>
                    <h3 className="text-2xl font-bold text-primary">Real-Time Analytics</h3>
                  </div>
                  <p className="text-muted-foreground">Advanced market analysis with AI-powered predictions and risk assessment tools.</p>
                </CardContent>
              </Card>
              
              <Card className="trading-card ultra-glass border-accent/30 hover:border-accent/60 transition-all duration-500 hover:scale-105 animate-scale-in" style={{animationDelay: "0.2s"}}>
                <CardContent className="p-8">
                  <div className="flex items-center mb-4">
                    <div className="w-12 h-12 bg-accent rounded-lg flex items-center justify-center mr-4 animate-pulse-glow">
                      <Box className="text-white" size={24} />
                    </div>
                    <h3 className="text-2xl font-bold text-accent">3D Visualizations</h3>
                  </div>
                  <p className="text-muted-foreground">Immersive 3D market data visualization for better trading insights and decision making.</p>
                </CardContent>
              </Card>
              
              <Card className="trading-card ultra-glass border-emerald-500/30 hover:border-emerald-500/60 transition-all duration-500 hover:scale-105 animate-scale-in" style={{animationDelay: "0.4s"}}>
                <CardContent className="p-8">
                  <div className="flex items-center mb-4">
                    <div className="w-12 h-12 bg-emerald-500 rounded-lg flex items-center justify-center mr-4 animate-pulse-glow">
                      <Shield className="text-white" size={24} />
                    </div>
                    <h3 className="text-2xl font-bold text-emerald-500">Premium Security</h3>
                  </div>
                  <p className="text-muted-foreground">Bank-grade security with multi-layer encryption and advanced fraud protection.</p>
                </CardContent>
              </Card>
            </div>
          </EnhancedScrollAnimated>
        </div>
      </div>
    </section>
  );
}

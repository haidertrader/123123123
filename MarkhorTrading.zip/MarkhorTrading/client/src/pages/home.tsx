import Navigation from "@/components/navigation";
import HeroSection from "@/components/hero-section";
import TradingChart from "@/components/trading-chart";
import AdvancedMarketOverview from "@/components/advanced-market-overview";
import TradingPlatform from "@/components/trading-platform";
import PremiumServices from "@/components/premium-services";
import ContactSection from "@/components/contact-section";
import Footer from "@/components/footer";
import EnhancedScrollAnimated from "@/components/enhanced-scroll-animations";

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-900 via-slate-800 to-slate-900 text-foreground overflow-x-hidden">
      <Navigation />
      <HeroSection />
      
      {/* Professional Trading Chart Section */}
      <section className="py-20 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-primary/5 via-transparent to-accent/5"></div>
        <div className="container mx-auto px-6 relative z-10">
          <EnhancedScrollAnimated direction="fade" duration={1.0}>
            <div className="text-center mb-12">
              <h2 className="text-4xl font-black mb-4 bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                Professional Trading Interface
              </h2>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                Real-time candlestick charts with professional-grade analysis tools and live market data
              </p>
            </div>
          </EnhancedScrollAnimated>
          
          <EnhancedScrollAnimated delay={300} direction="scale" duration={1.2}>
            <TradingChart />
          </EnhancedScrollAnimated>
        </div>
      </section>

      {/* Advanced Market Overview */}
      <AdvancedMarketOverview />
      
      {/* Trading Platform Section */}
      <section className="py-20 relative">
        <div className="absolute inset-0 bg-gradient-to-r from-emerald-900/20 via-transparent to-blue-900/20"></div>
        <div className="container mx-auto px-6 relative z-10">
          <EnhancedScrollAnimated direction="up" duration={1.0}>
            <TradingPlatform />
          </EnhancedScrollAnimated>
        </div>
      </section>

      {/* Premium Services */}
      <section className="py-20 relative">
        <div className="container mx-auto px-6">
          <EnhancedScrollAnimated direction="blur" duration={1.0}>
            <PremiumServices />
          </EnhancedScrollAnimated>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-20 relative">
        <div className="absolute inset-0 bg-gradient-to-t from-slate-900 to-transparent"></div>
        <div className="container mx-auto px-6 relative z-10">
          <EnhancedScrollAnimated direction="scale" duration={1.0}>
            <ContactSection />
          </EnhancedScrollAnimated>
        </div>
      </section>

      <Footer />
    </div>
  );
}
